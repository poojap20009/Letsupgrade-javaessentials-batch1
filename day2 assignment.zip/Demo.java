class Employee
{
	String name="saurab";
	int age=23;
	String city="chennai";
	void display()
	{
		System.out.println("The name is "+name);
		System.out.println("The age is"+age);
		System.out.println("The city is"+city);
	}
}
class Demo
{
public static void main(String args[])
{
	Employee emp=new Employee();
	Employee emp1=new Employee();	
	emp.display();
	emp1.display();
}
}